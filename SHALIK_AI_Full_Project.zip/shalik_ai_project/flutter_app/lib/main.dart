import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const ShalikApp());

class ShalikApp extends StatelessWidget {
  const ShalikApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SHALIK AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1769AA)),
        useMaterial3: true,
      ),
      home: const ChatPage(),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;
  final String provider;
  ChatMessage(this.text, {required this.isUser, this.provider = ''});
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  // Replace this with your deployed HTTPS backend URL before building the APK.
  // Android emulator local backend: http://10.0.2.2:3000
  // Physical phone: use your deployed HTTPS backend URL.
  static const String backendUrl = 'https://YOUR-BACKEND-DOMAIN.example.com';

  final input = TextEditingController();
  final scroll = ScrollController();
  final List<ChatMessage> messages = [];
  String selectedProvider = 'gemini';
  bool loading = false;

  final providerNames = const {
    'gemini': 'Gemini',
    'chatgpt': 'ChatGPT',
    'grok': 'Grok',
    'deepseek': 'DeepSeek',
  };

  Future<void> send() async {
    final question = input.text.trim();
    if (question.isEmpty || loading) return;

    setState(() {
      messages.add(ChatMessage(question, isUser: true));
      loading = true;
    });
    input.clear();
    _scrollToBottom();

    try {
      final response = await http
          .post(
            Uri.parse('$backendUrl/chat'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'provider': selectedProvider,
              'message': question,
            }),
          )
          .timeout(const Duration(seconds: 90));

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      if (response.statusCode >= 200 && response.statusCode < 300) {
        setState(() => messages.add(ChatMessage(
              (data['answer'] ?? 'No answer returned.').toString(),
              isUser: false,
              provider: providerNames[selectedProvider]!,
            )));
      } else {
        setState(() => messages.add(ChatMessage(
              (data['error'] ?? 'সার্ভারে সমস্যা হয়েছে।').toString(),
              isUser: false,
            )));
      }
    } catch (_) {
      setState(() => messages.add(ChatMessage(
            'সার্ভারের সঙ্গে সংযোগ হচ্ছে না। Backend URL ও ইন্টারনেট পরীক্ষা করো।',
            isUser: false,
          )));
    } finally {
      if (mounted) {
        setState(() => loading = false);
        _scrollToBottom();
      }
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(
          scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('SHALIK AI', style: TextStyle(fontWeight: FontWeight.bold)),
            Text('তোমার AI সহকারী', style: TextStyle(fontSize: 11)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'নতুন চ্যাট',
            onPressed: loading ? null : () => setState(messages.clear),
            icon: const Icon(Icons.add_comment_outlined),
          )
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            child: DropdownButtonFormField<String>(
              value: selectedProvider,
              decoration: const InputDecoration(
                labelText: 'AI মডেল নির্বাচন করো',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.auto_awesome),
              ),
              items: providerNames.entries
                  .map((entry) => DropdownMenuItem(
                        value: entry.key,
                        child: Text(entry.value),
                      ))
                  .toList(),
              onChanged: loading
                  ? null
                  : (value) {
                      if (value != null) {
                        setState(() => selectedProvider = value);
                      }
                    },
            ),
          ),
          Expanded(
            child: messages.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.auto_awesome,
                              size: 58,
                              color: Theme.of(context).colorScheme.primary),
                          const SizedBox(height: 12),
                          const Text('স্বাগতম SHALIK AI-তে!',
                              style: TextStyle(
                                  fontSize: 21, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 6),
                          const Text('যেকোনো ভাষায় তোমার প্রশ্ন লিখে পাঠাও।',
                              textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: scroll,
                    padding: const EdgeInsets.all(12),
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final message = messages[index];
                      return Align(
                        alignment: message.isUser
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          constraints: BoxConstraints(
                              maxWidth:
                                  MediaQuery.of(context).size.width * 0.84),
                          margin: const EdgeInsets.symmetric(vertical: 5),
                          padding: const EdgeInsets.all(13),
                          decoration: BoxDecoration(
                            color: message.isUser
                                ? Theme.of(context).colorScheme.primary
                                : Theme.of(context)
                                    .colorScheme
                                    .surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (!message.isUser &&
                                  message.provider.isNotEmpty)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 5),
                                  child: Text(message.provider,
                                      style: const TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold)),
                                ),
                              SelectableText(
                                message.text,
                                style: TextStyle(
                                  color: message.isUser
                                      ? Colors.white
                                      : Theme.of(context)
                                          .colorScheme
                                          .onSurface,
                                  height: 1.4,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          if (loading)
            const Padding(
              padding: EdgeInsets.all(8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2)),
                  SizedBox(width: 10),
                  Text('উত্তর তৈরি হচ্ছে...'),
                ],
              ),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: input,
                      minLines: 1,
                      maxLines: 5,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => send(),
                      decoration: const InputDecoration(
                        hintText: 'এখানে প্রশ্ন লেখো...',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton.filled(
                    onPressed: loading ? null : send,
                    icon: const Icon(Icons.send),
                    tooltip: 'পাঠাও',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}