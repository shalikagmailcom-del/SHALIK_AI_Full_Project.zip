import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import rateLimit from "express-rate-limit";

dotenv.config();

const app = express();
app.use(express.json({ limit: "1mb" }));

const allowedOrigin = process.env.CORS_ORIGIN || "*";
app.use(cors({
  origin: allowedOrigin === "*" ? true : allowedOrigin.split(",").map(s => s.trim())
}));

app.use(rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false
}));

const providers = {
  gemini: {
    key: () => process.env.GEMINI_API_KEY,
    model: () => process.env.GEMINI_MODEL || "gemini-2.5-flash"
  },
  chatgpt: {
    key: () => process.env.OPENAI_API_KEY,
    model: () => process.env.OPENAI_MODEL || "gpt-6-astra"
  },
  grok: {
    key: () => process.env.XAI_API_KEY,
    model: () => process.env.XAI_MODEL || "grok-4.7"
  },
  deepseek: {
    key: () => process.env.DEEPSEEK_API_KEY,
    model: () => process.env.DEEPSEEK_MODEL || "deepseek-v4-pro"
  }
};

app.get("/health", (_req, res) => res.json({ ok: true, app: "SHALIK AI" }));

app.post("/chat", async (req, res) => {
  const providerName = String(req.body?.provider || "").toLowerCase();
  const message = String(req.body?.message || "").trim();

  if (!providers[providerName]) {
    return res.status(400).json({ error: "Unknown AI provider." });
  }
  if (!message || message.length > 12000) {
    return res.status(400).json({ error: "Message is empty or too long (max 12000 characters)." });
  }

  const provider = providers[providerName];
  const apiKey = provider.key();
  if (!apiKey) {
    return res.status(503).json({
      error: `${providerName} API key is not configured on the server.`
    });
  }

  try {
    let answer = "";

    if (providerName === "gemini") {
      const model = provider.model();
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
      const upstream = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "You are SHALIK AI, a helpful assistant. Reply in the language used by the user unless they request another language. Be accurate, clear, and age-appropriate." }]
          },
          contents: [{ role: "user", parts: [{ text: message }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
        })
      });
      const data = await upstream.json();
      if (!upstream.ok) {
        return res.status(502).json({ error: data?.error?.message || "Gemini request failed." });
      }
      answer = (data.candidates?.[0]?.content?.parts || [])
        .map(part => part.text || "").join("\n").trim();
    } else {
      const configs = {
        chatgpt: { url: "https://api.openai.com/v1/chat/completions" },
        grok: { url: "https://api.x.ai/v1/chat/completions" },
        deepseek: { url: "https://api.deepseek.com/chat/completions" }
      };
      const upstream = await fetch(configs[providerName].url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: provider.model(),
          messages: [
            {
              role: "system",
              content: "You are SHALIK AI, a helpful assistant. Reply in the language used by the user unless they request another language. Be accurate, clear, and age-appropriate."
            },
            { role: "user", content: message }
          ],
          max_tokens: 2048
        })
      });
      const data = await upstream.json();
      if (!upstream.ok) {
        return res.status(502).json({ error: data?.error?.message || `${providerName} request failed.` });
      }
      answer = data.choices?.[0]?.message?.content?.trim() || "";
    }

    if (!answer) {
      return res.status(502).json({ error: "AI returned an empty response. Please try again." });
    }
    return res.json({ answer, provider: providerName });
  } catch (error) {
    console.error("AI request error:", error.message);
    return res.status(502).json({ error: "Could not connect to the AI provider. Please try again." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`SHALIK AI backend listening on port ${port}`));