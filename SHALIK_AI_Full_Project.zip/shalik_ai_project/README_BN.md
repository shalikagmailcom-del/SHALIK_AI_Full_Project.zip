# SHALIK AI — Flutter + Node.js Backend

এই starter project-এ Flutter Android chat app এবং চারটি provider-এর জন্য Node.js backend আছে:
Gemini, ChatGPT (OpenAI API), Grok (xAI API), DeepSeek।

## গুরুত্বপূর্ণ
- এই ZIP সরাসরি তৈরি APK নয়; এটি APK build করার source code।
- চারটি provider-এর API key ও তাদের ব্যবহারের অনুমতি/বিলিং আলাদাভাবে লাগতে পারে।
- API key কখনো Flutter code বা APK-তে রাখবে না।
- Default model নাম অ্যাকাউন্টে না চললে backend `.env`-এ নিজের অ্যাকাউন্টে উপলভ্য model ID বসাও।
- ব্যবহার অনুযায়ী API খরচ হতে পারে। API key-এর usage limit/budget সেট করো।

## 1) Backend চালু করা
কম্পিউটারে Node.js 20+ ইনস্টল করো।

```bash
cd backend
npm install
```

`.env.example` কপি করে `.env` নাম দাও এবং চারটি API key বসাও। যে provider ব্যবহার করবে না, তার key ফাঁকা রাখতে পারো।

```bash
npm start
```

Backend চালু হলে `http://localhost:3000/health` খুলে `{"ok":true,...}` দেখতে পাবে।

Production APK-এর জন্য backend-কে HTTPS-সহ কোনো Node.js hosting service-এ deploy করতে হবে। তারপর সেই HTTPS URL Flutter code-এ বসাতে হবে।

## 2) Flutter app প্রস্তুত করা
Flutter SDK ও Android SDK-সহ কম্পিউটারে:

```bash
cd flutter_app
flutter pub get
```

`lib/main.dart`-এ `backendUrl`-এর placeholder বদলে নিজের deployed HTTPS backend URL বসাও।

## 3) Internet permission
`flutter_app/android/app/src/main/AndroidManifest.xml`-এ `<application>` ট্যাগের আগে এই লাইনটি আছে কি না দেখো:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

Flutter template-এ সাধারণত এটি আগে থেকেই থাকে।

## 4) APK তৈরি
```bash
flutter build apk --release
```

APK পাওয়া যাবে:
`build/app/outputs/flutter-apk/app-release.apk`

## 5) API key কোথায় পাবে
প্রতিটি AI provider-এর নিজস্ব developer console-এ API access ও key তৈরি করতে হয়। Key শুধু backend `.env`-এ রাখবে।

## API routes
- `GET /health` — backend status
- `POST /chat` — body: `{"provider":"gemini","message":"Hello"}`

Provider values: `gemini`, `chatgpt`, `grok`, `deepseek`.

## Troubleshooting
- `API key is not configured`: `.env`-এ সংশ্লিষ্ট key বসাও, backend restart করো।
- `model not found` বা access error: provider account-এ উপলভ্য model ID `.env`-এ সেট করো।
- App cannot connect: `backendUrl` সঠিক HTTPS URL কি না এবং backend চালু কি না দেখো।
- ফোনে `localhost` ব্যবহার কোরো না; সেটি ফোনকেই বোঝায়, তোমার hosting server নয়।
